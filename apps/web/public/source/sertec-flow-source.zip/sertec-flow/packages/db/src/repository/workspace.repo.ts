import {
  and,
  asc,
  count,
  desc,
  eq,
  ilike,
  inArray,
  isNull,
  ne,
  or,
  sql,
} from "drizzle-orm";

import type { dbClient } from "@kan/db/client";
import type { Permission, Role } from "@kan/shared";
import {
  boards,
  cards,
  lists,
  workspaceMembers,
  workspaces,
} from "@kan/db/schema";
import {
  generateUID,
  generateWorkspacePrefix,
  getDefaultPermissions,
} from "@kan/shared";

import * as permissionRepo from "./permission.repo";

// System role definitions
const SYSTEM_ROLES: {
  name: Role;
  description: string;
  hierarchyLevel: number;
}[] = [
  {
    name: "admin",
    description: "Full access to all workspace features",
    hierarchyLevel: 100,
  },
  {
    name: "member",
    description: "Standard member with create and edit permissions",
    hierarchyLevel: 50,
  },
  {
    name: "guest",
    description: "View-only access",
    hierarchyLevel: 10,
  },
];

export const getCount = async (db: dbClient) => {
  const result = await db
    .select({ count: count() })
    .from(workspaces)
    .where(isNull(workspaces.deletedAt));

  return result[0]?.count ?? 0;
};

export const create = async (
  db: dbClient,
  workspaceInput: {
    publicId?: string;
    name: string;
    slug: string;
    createdBy: string;
    createdByEmail: string;
    description?: string;
    plan?: "free" | "team" | "pro" | "enterprise";
  },
) => {
  const [workspace] = await db
    .insert(workspaces)
    .values({
      publicId: workspaceInput.publicId ?? generateUID(),
      name: workspaceInput.name,
      slug: workspaceInput.slug,
      createdBy: workspaceInput.createdBy,
      ...(workspaceInput.description && {
        description: workspaceInput.description,
      }),
      ...(workspaceInput.plan && { plan: workspaceInput.plan }),
      cardPrefix: generateWorkspacePrefix(workspaceInput.name),
      cardCounter: 0,
    })
    .returning({
      id: workspaces.id,
      publicId: workspaces.publicId,
      name: workspaces.name,
      slug: workspaces.slug,
      description: workspaces.description,
      plan: workspaces.plan,
      cardPrefix: workspaces.cardPrefix,
    });

  if (workspace) {
    // Create system roles for the workspace
    let adminRoleId: number | null = null;
    for (const roleData of SYSTEM_ROLES) {
      const role = await permissionRepo.createRole(db, {
        workspaceId: workspace.id,
        name: roleData.name,
        description: roleData.description,
        hierarchyLevel: roleData.hierarchyLevel,
        isSystem: true,
        permissions: [...getDefaultPermissions(roleData.name)] as Permission[],
      });
      if (roleData.name === "admin" && role) {
        adminRoleId = role.id;
      }
    }

    await db.insert(workspaceMembers).values({
      publicId: generateUID(),
      userId: workspaceInput.createdBy,
      email: workspaceInput.createdByEmail,
      workspaceId: workspace.id,
      createdBy: workspaceInput.createdBy,
      role: "admin",
      roleId: adminRoleId,
      status: "active",
    });
  }

  const newWorkspace = { ...workspace };
  delete newWorkspace.id;

  return newWorkspace;
};

export const update = async (
  db: dbClient,
  workspacePublicId: string,
  workspaceInput: {
    name?: string;
    slug?: string;
    plan?: "free" | "team" | "pro" | "enterprise";
    description?: string;
    showEmailsToMembers?: boolean;
    weekStartDay?: number;
  },
) => {
  const [result] = await db
    .update(workspaces)
    .set({
      name: workspaceInput.name,
      slug: workspaceInput.slug,
      plan: workspaceInput.plan,
      description: workspaceInput.description,
      showEmailsToMembers: workspaceInput.showEmailsToMembers,
      weekStartDay: workspaceInput.weekStartDay,
    })
    .where(eq(workspaces.publicId, workspacePublicId))
    .returning({
      id: workspaces.id,
      publicId: workspaces.publicId,
      name: workspaces.name,
      slug: workspaces.slug,
      description: workspaces.description,
      plan: workspaces.plan,
      showEmailsToMembers: workspaces.showEmailsToMembers,
      weekStartDay: workspaces.weekStartDay,
    });

  return result;
};

export const getByPublicId = (db: dbClient, workspacePublicId: string) => {
  return db.query.workspaces.findFirst({
    columns: {
      id: true,
      publicId: true,
      name: true,
      plan: true,
      slug: true,
      deletedAt: true,
      createdBy: true,
    },
    where: eq(workspaces.publicId, workspacePublicId),
  });
};

export const getById = (db: dbClient, workspaceId: number) => {
  return db.query.workspaces.findFirst({
    columns: {
      id: true,
      publicId: true,
      name: true,
      plan: true,
      slug: true,
    },
    where: eq(workspaces.id, workspaceId),
  });
};

export const getByPublicIdWithMembers = (
  db: dbClient,
  workspacePublicId: string,
) => {
  return db.query.workspaces.findFirst({
    columns: {
      id: true,
      publicId: true,
      name: true,
      slug: true,
      showEmailsToMembers: true,
      weekStartDay: true,
    },
    with: {
      members: {
        columns: {
          publicId: true,
          email: true,
          role: true,
          status: true,
          createdAt: true,
        },
        where: isNull(workspaceMembers.deletedAt),
        orderBy: (member, { desc }) => [
          desc(sql`CASE WHEN ${member.role} = 'admin' THEN 1 ELSE 0 END`),
          desc(member.createdAt),
        ],
        with: {
          user: {
            columns: {
              id: true,
              name: true,
              email: true,
              image: true,
            },
          },
        },
      },
      subscriptions: {
        columns: {
          id: true,
          plan: true,
          status: true,
          seats: true,
          unlimitedSeats: true,
          partnerTier: true,
          periodStart: true,
          periodEnd: true,
        },
      },
    },
    where: and(
      eq(workspaces.publicId, workspacePublicId),
      isNull(workspaces.deletedAt),
    ),
  });
};

export const getBySlugWithBoards = (db: dbClient, workspaceSlug: string) => {
  return db.query.workspaces.findFirst({
    columns: {
      id: true,
      publicId: true,
      name: true,
      description: true,
      slug: true,
    },
    with: {
      boards: {
        columns: {
          publicId: true,
          slug: true,
          name: true,
        },
        where: and(
          isNull(boards.deletedAt),
          eq(boards.visibility, "public"),
          eq(boards.isArchived, false),
        ),
        orderBy: [asc(boards.name)],
      },
    },
    where: and(
      eq(workspaces.slug, workspaceSlug),
      isNull(workspaces.deletedAt),
    ),
  });
};

export const getAllByUserId = async (db: dbClient, userId: string) => {
  const result = await db.query.workspaceMembers.findMany({
    columns: {
      role: true,
    },
    with: {
      workspace: {
        columns: {
          publicId: true,
          name: true,
          description: true,
          slug: true,
          plan: true,
          weekStartDay: true,
          cardPrefix: true,
          deletedAt: true,
        },
        // https://github.com/drizzle-team/drizzle-orm/issues/2903
        // where: isNull(workspaces.deletedAt),
      },
    },
    where: and(
      eq(workspaceMembers.userId, userId),
      eq(workspaceMembers.status, "active"),
      isNull(workspaceMembers.deletedAt),
    ),
  });

  return result.filter((member) => !member.workspace.deletedAt);
};

export const getAllOwnedByUserId = async (db: dbClient, userId: string) => {
  return await db.query.workspaces.findMany({
    columns: {
      publicId: true,
      plan: true,
    },
    where: and(eq(workspaces.createdBy, userId), isNull(workspaces.deletedAt)),
  });
};

export const getMemberByPublicId = (
  db: dbClient,
  memberPublicId: string,
  workspaceId: number,
) => {
  return db.query.workspaceMembers.findFirst({
    columns: {
      id: true,
    },
    where: and(
      eq(workspaceMembers.publicId, memberPublicId),
      eq(workspaceMembers.workspaceId, workspaceId),
      isNull(workspaceMembers.deletedAt),
    ),
  });
};

export const getAllMembersByPublicIds = (
  db: dbClient,
  memberPublicIds: string[],
  workspaceId: number,
) => {
  return db.query.workspaceMembers.findMany({
    columns: {
      id: true,
    },
    where: and(
      inArray(workspaceMembers.publicId, memberPublicIds),
      eq(workspaceMembers.workspaceId, workspaceId),
      isNull(workspaceMembers.deletedAt),
    ),
  });
};

export const hardDelete = (db: dbClient, workspacePublicId: string) => {
  return db
    .delete(workspaces)
    .where(eq(workspaces.publicId, workspacePublicId));
};

export const isWorkspaceSlugAvailable = async (
  db: dbClient,
  workspaceSlug: string,
  excludeWorkspaceId?: number,
) => {
  const result = await db.query.workspaces.findFirst({
    columns: {
      id: true,
    },
    where: and(
      isNull(workspaces.deletedAt),
      or(
        eq(workspaces.slug, workspaceSlug),
        // A workspace's own publicId is always reserved for itself as a
        // slug (that's what it falls back to when it has no custom slug),
        // so no other workspace may claim it as a custom slug either.
        and(
          eq(workspaces.publicId, workspaceSlug),
          excludeWorkspaceId ? ne(workspaces.id, excludeWorkspaceId) : undefined,
        ),
      ),
    ),
  });

  return result === undefined;
};

export const isUserInWorkspace = async (
  db: dbClient,
  userId: string,
  workspaceId: number,
  role?: "admin" | "member",
) => {
  const result = await db.query.workspaceMembers.findFirst({
    columns: {
      id: true,
    },
    where: and(
      eq(workspaceMembers.userId, userId),
      eq(workspaceMembers.workspaceId, workspaceId),
      eq(workspaceMembers.status, "active"),
      isNull(workspaceMembers.deletedAt),
      role ? eq(workspaceMembers.role, role) : undefined,
    ),
  });

  return result?.id !== undefined;
};

const parseTicketId = (
  query: string,
): { prefix: string; number: number } | null => {
  const match = /^([A-Za-z0-9]{1,10})-(\d+)$/.exec(query);
  if (!match) return null;
  return { prefix: match[1]!.toUpperCase(), number: parseInt(match[2]!, 10) };
};

export const searchBoardsAndCards = async (
  db: dbClient,
  workspaceId: number,
  query: string,
  limit = 20,
) => {
  const searchQuery = `%${query}%`;

  const ticketId = parseTicketId(query.trim());

  // Search for boards
  const boardResults = await db
    .select({
      publicId: boards.publicId,
      title: boards.name,
      description: boards.description,
      slug: boards.slug,
      updatedAt: boards.updatedAt,
      createdAt: boards.createdAt,
    })
    .from(boards)
    .where(
      and(
        eq(boards.workspaceId, workspaceId),
        // Combine exact and fuzzy matching
        or(
          ilike(boards.name, `%${query}%`), // Exact substring match
          sql`similarity(${boards.name}, ${query}) > 0.2`, // Fuzzy match
        ),
        isNull(boards.deletedAt),
      ),
    )
    .orderBy(
      sql`CASE WHEN ${boards.name} ILIKE ${`%${query}%`} THEN 1 ELSE 0 END DESC`,
      sql`similarity(${boards.name}, ${query}) DESC`,
      desc(boards.updatedAt),
    )
    .limit(ticketId ? 0 : Math.ceil(limit * 0.4));

  // Search for cards by ticket ID or by title
  const cardWhereConditions = ticketId
    ? and(
        eq(boards.workspaceId, workspaceId),
        eq(cards.cardNumber, ticketId.number),
        ilike(workspaces.cardPrefix, ticketId.prefix),
        isNull(cards.deletedAt),
        isNull(lists.deletedAt),
        isNull(boards.deletedAt),
      )
    : and(
        eq(boards.workspaceId, workspaceId),
        or(
          ilike(cards.title, searchQuery),
          sql`similarity(${cards.title}, ${query}) > 0.2`,
        ),
        isNull(cards.deletedAt),
        isNull(lists.deletedAt),
        isNull(boards.deletedAt),
      );

  const cardResults = await db
    .select({
      publicId: cards.publicId,
      title: cards.title,
      description: cards.description,
      boardPublicId: boards.publicId,
      boardName: boards.name,
      listName: lists.name,
      cardNumber: cards.cardNumber,
      updatedAt: cards.updatedAt,
      createdAt: cards.createdAt,
    })
    .from(cards)
    .innerJoin(lists, eq(cards.listId, lists.id))
    .innerJoin(boards, eq(lists.boardId, boards.id))
    .innerJoin(workspaces, eq(boards.workspaceId, workspaces.id))
    .where(cardWhereConditions)
    .orderBy(
      ...(ticketId
        ? [desc(cards.createdAt)]
        : [
            sql`CASE WHEN ${cards.title} ILIKE ${searchQuery} THEN 1 ELSE 0 END DESC`,
            sql`similarity(${cards.title}, ${query}) DESC`,
            desc(cards.updatedAt),
          ]),
    )
    .limit(ticketId ? limit : Math.floor(limit * 0.6));

  // Combine results
  const allResults = [
    ...boardResults.map((board) => ({
      ...board,
      type: "board" as const,
    })),
    ...cardResults.map((card) => ({
      ...card,
      type: "card" as const,
    })),
  ];

  // Ensure we don't exceed the total limit
  return allResults.slice(0, limit);
};

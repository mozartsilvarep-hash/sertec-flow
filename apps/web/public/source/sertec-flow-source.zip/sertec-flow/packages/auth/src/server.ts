export { initAuth } from "./auth";

export const locales = [
  "en",
  "fr",
  "de",
  "es",
  "it",
  "nl",
  "ru",
  "pl",
  "pt-BR",
] as const;

export type Locale = (typeof locales)[number];

export const defaultLocale: Locale = "pt-BR";

export const localeNames: Record<Locale, string> = {
  en: "English",
  fr: "Français",
  de: "Deutsch",
  es: "Español",
  it: "Italiano",
  nl: "Nederlands",
  ru: "Русский",
  pl: "Polski",
  "pt-BR": "Português (Brasil)",
};

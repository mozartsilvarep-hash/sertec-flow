export { default } from "../planos";

module.exports = {
  plugins: {
    tailwindcss: {},
  },
};
